
let config = {
	type: Phaser.AUTO,
	width:  256,
	height: 240,
	pixelArt: true,
	scale: {
		autoCenter: Phaser.Scale.CENTER_HORIZONTALLY,
		mode: Phaser.Scale.FIT,
		min: {
            width: 256,
            height: 240
        },
		max: {
            width:  960, 
            height: 640  
        }
	},
	scene: [],	
	physics: { 
		default: 'arcade', 
		arcade: { 
			gravity: { y: 40 }, 
			debug: true 
		} 
	}

};

new Phaser.Game(config);