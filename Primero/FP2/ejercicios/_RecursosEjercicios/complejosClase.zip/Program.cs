﻿using System;


namespace complejosClase{
    class Program
    {
        
        static void Main(string[] args)
        {
            Complex c1 = new Complex(2,3),
                    c2 = new Complex(_im:9);
                    

            c1.SumaComplex(c2);
            c1.Escribe();     
            System.Console.WriteLine();
            return;


            //c1.re = 0; // no funciona 
            c1.SetRe(0);
            c1.Escribe(); 
            Console.WriteLine();



            c1.Escribe(); 

            Complex c3 = new Complex();
            c3.Lee();
       

            Complex c4 = new Complex();
            c4.Lee();
            
            
            Console.WriteLine(c3);

            Console.WriteLine(c3==c4);



            // funciona si se definen las propiedades en la clase
            //c4.Re = 0;


        }
    }





}
