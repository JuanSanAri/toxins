using System;


namespace complejosClase{

    public class Complex{
        // campos/atributos de la clase
        private double re, im;

        // constructora sin argumentos: inicializa a 0+0i
        //public Complex(){ re = im = 0;}

        // SOBRECARGA de la constructora, con argumentos
        //public Complex(double _re, double _im){ re = _re; im = _im ; }

        //public Complex(double re, double im){ this.re = re; this.im = im ; }


        // get para la parte real
        /*
        public double GetRe() {return re;}
 
        // get para la imaginaria
        public double GetIm() {return im;}
        public void SetIm(double val){ im = val;}
        public void SetRe(double val){ re = val;}
        */
        
        public void SumaComplex(Complex num) { 
            re += num.re;
            im += num.im;
        }

        public void Escribe(){
            Console.Write($"{re} + {im}i");
        }

        public void Lee(){  // parseo de una cadena de la forma  345  +  235i
            Console.Write("Re: ");
            re = double.Parse(Console.ReadLine());
            Console.Write("Im: ");
            im = double.Parse(Console.ReadLine());

        }


        // Alternativa con inicialización por defecto. Sobran las dos anteriores
        public Complex(double _re=0, double _im=0){ re = _re; im = _im ; }

        // Alternativa "propiedades" get/set para acceso directo a los campos
        // Sobrarían los "Get" y "Set" anteriores

//        public double Re{
//            get => re;
//            set => re = value;
//        }        

        public double Re{
            get{ return re;}
            set{re = value;}
        }        

  //      public double Im{
  //          get => im;
  //          set => im = value;
  //      }        

        public double Im{
            get{ return im;}
            set{im = value;}
        }        




        // sobrecarda del operador +
        //public static Complex operator +(Complex num1, Complex num2) { // +_ComplexComplex
        //    return new Complex(num1.re + num2.re, num1.im + num2.im);  
        //}

        //// otra sobrecarga del operador + para double+complex
        //public static Complex operator +(double num1, Complex num2) { // +_ComplexComplex
        //    return new Complex(num1 + num2.re, num2.im);  
        //}

        //public static Complex operator -(Complex num1, Complex num2) {
        //    return new Complex(num1.re - num2.re, num1.im - num2.im); 
        //}

        //// sobrecarga del operador ==
        //public static bool operator ==(Complex num1, Complex num2) {
        //    return (num1.re==num2.re) && (num1.im == num2.im); 
        //}    

        //
        //public static  bool operator !=(Complex num1, Complex num2) {
        //    return !(num1==num2); //(num1.re==num2.re) && (num2.im - num2.im); 
        //} 
        //   

        //// método ToString que se invoca implícitamente cuando se hace Console.Write
        //public override string ToString() { // => $"{num} / {den}";        
        //    //return String.Format("{0} + {1}i",re,im);
        //    return $"{re} + {im}i";  // sintaxis para los formatos de cadena
        //}
    

    
    }
}